setwd("/Users/shannamaeyang/Desktop/PS0002")
comp=read.csv("computers.csv", header = TRUE, sep=",")
head(comp)
summary(comp)
dim(comp1)
comp1=comp[complete.cases(comp),]

arr=scale(USArrests)
k2=kmeans(arr, centers=2, nstart=25)
str(k2)

#Find optimal number of clusters K
wcss=function(k){
  kmeans(arr, k,nstart=10)$tot.withinss
}
k.values=1:15
set.seed(100)
wcss_k=sapply(k.values,wcss)
plot(k.values,wcss_k, type="b",pch=19, frame=False, xlab="Number of clusters K", ylab="Total within-clusters sum of squares")

#final c;ustering with optimal k=4
set.seed(100)
k4.final=kmeans(arr,4,nstart=25)
k4.final
library(dplyr)
USArrests%>%mutate(Cluster=k4.final$cluster)%>%group_by(Cluster)%>% summarise_all("mean")


#Hierarchical Clustering
#dissimilarity matrix
d=dist(arr, method="euclidean")
hc1=hclust(d,method="complete")
plot(hc1,cex=0.6, hang=-1)
rect.hclust(hc1, k = 4, border = 2:5)