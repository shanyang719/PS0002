setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
library(dplyr)
summary(msleep)

#1
rg=function(x){
  x=na.omit(x)
  max(x)-min(x)
}
colnames(msleep)
sleep_stats=msleep%>%group_by(vore)%>%
  summarise(count=n(),ave_sleep=mean(sleep_total,na.rm=TRUE),sd_sleep=sd(sleep_total,na.rm=TRUE),rg.sleep=rg(sleep_total))
ggplot(sleep_stats,aes(x=vore,y=ave_sleep))+geom_bar(stat="identity")
ggplot(sleep_stats,aes(x=vore,y=sd_sleep))+geom_bar(stat="identity")
ggplot(sleep_stats,aes(x=vore,y=rg.sleep))+geom_bar(stat="identity")

ggplot(msleep,aes(sleep_total))+geom_histogram(bins=20,na.rm=TRUE)
ggplot(msleep,aes(sleep_total))+geom_density()

ggplot(msleep,aes(sleep_total))+geom_histogram(bins=20,na.rm=TRUE)
ggplot(msleep,aes(sleep_total))+geom_density(alpha=0.2,fill="pink")
ggplot(msleep,aes(sleep_total))+geom_histogram(bins=20,aes(y=..density..),colour="black",fill="white",na.rm=TRUE)+geom_density(alpha=0.2,fill="pink")

sleep1=msleep%>%filter(brainwt<0.1)%>%
  mutate(rem_ratio=sleep_rem/sleep_total)
ggplot(sleep1,aes(x=brainwt,y=rem_ratio,col=vore))+geom_point()


