setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
install.packages("caret")
install.packages("nycflights13")
library(dplyr)
library(ggplot2)
library(nycflights13)
head(flights)
colnames(flights)
flights1=flights%>%mutate(gain=arr_delay-dep_delay)
longdistflights=flights1%>%filter(air_time>550,carrier=="UA")
ggplot(longdistflights,aes(x=air_time,y=gain))+geom_point()+geom_smooth()

summary(longdistflights)
colnames(longdistflights)
head(longdistflights)
dim(longdistflights)
#split the data

set.seed(100)
training.idx=sample(1:nrow(longdistflights),nrow(longdistflights)*0.8)
train.data=longdistflights[training.idx,]
test.data=longdistflights[-training.idx,]

#Step 4: Fit the model
library(caret)
set.seed(101)
model=train(gain~air_time,data=train.data, method="knn",trControl=trainControl("cv",number=6),preProcess=c("center","scale"),tuneLength=10)
model$bestTune

predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$gain)
plot(test.data$gain,predictions,main="Prediction performance butt")
abline(0,1,col="red")


#Linear regression  9.926826
lmodel=lm(gain~air_time,data=train.data)
summary(lmodel)

#Step 3: Interpretation
predictions=predict(lmodel,test.data)
head(predictions)
plot(test.data$gain,predictions,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions,test.data$gain)

#Step 4: Look at the residuals
par(mfrow=c(2,2))
plot(lmodel)


#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)

#Step 6: remove outliers
Boston1=Boston[-c(65,178,195),]
set.seed(100)
training.idx=sample(1:nrow(Boston1),size=nrow(Boston1)*0.8)
train.data=Boston1[training.idx,]
test.data=Boston1[-training.idx,]

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+black+lstat+I(rm^2)+I(ptratio^2)+I(lstat^2)+I(indus^2),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$medv)
plot(p2model)                  

