setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
library(ggplot2)
library(caret) 
library(psych)
data(marketing, package = "datarium")
head(marketing)
summary(marketing)

#visualise relationships
pairs.panels(marketing,method="pearson", hist.col="steelblue",pch=21,bg=c("pink","light green","light blue")[marketing$sales],density=TRUE,ellipses=FALSE)


#split data
set.seed(100)
training.idx=sample(1:nrow(marketing),nrow(marketing)*0.8)
train.data=marketing[training.idx,]
test.data=marketing[-training.idx,]

#KNN model
set.seed(101)
model=train(sales~.,data=train.data, method="knn",trControl=trainControl("cv",number=4),preProcess=c("center","scale"),tuneLength=10)
model$bestTune
#k=5
predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$sales)
#1.366957
plot(test.data$sales,predictions,main="Prediction performance ")
abline(0,1,col="red")


#Linear regression model
lmodel=lm(sales~.,data=train.data)
summary(lmodel)
predictions=predict(lmodel,test.data)
head(predictions)
plot(test.data$sales,predictions,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions,test.data$sales)
#1.95369

#Check residuals
par(mfrow=c(2,2))
plot(lmodel)


#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)

#Step 6: remove outliers
marketing1=marketing[-c(36,131,179),]
set.seed(100)
training.idx=sample(1:nrow(marketing1),size=nrow(marketing1)*0.8)
train.data=marketing1[training.idx,]
test.data=marketing1[-training.idx,]

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(sales~youtube+facebook+newspaper+I(youtube^2)+I(facebook^2),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$sales)
plot(p2model)                  

