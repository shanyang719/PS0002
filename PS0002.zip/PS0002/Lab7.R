setwd("/Users/shannamaeyang/Desktop/PS0002")
grad=read.csv("gradadmit.csv", header = TRUE, sep=",")
head(grad)
dim(grad)
#Step1: Prepare Data
grad=grad[complete.cases(grad),]
dim(grad)
grad$admit <- factor(grad$admit)
grad$rank <- factor(grad$rank)
#Step 2: Split data
set.seed(100)
training.idx= sample(1: nrow(grad), size=nrow(grad)*0.8)
train.data=grad[training.idx, ]
test.data=grad[-training.idx, ]

#Step 3: Logistic Regression Model

mlogit= glm(admit~.,data=train.data,family="binomial")
summary(mlogit)
#gre          0.001697  => For every 1 unit increase in gre results, ln(odds) of being malignant increase by 0.001697  
#gpa          0.813302   
#rank        -0.544522 

#Step 4: Predict
Pred.p =predict(mlogit, newdata =test.data, type = "response")

y_pred_num =ifelse(Pred.p > 0.5, 1, 0)
y_pred =factor(y_pred_num, levels=c(0, 1))
#Accuracy of the classification
mean(y_pred ==test.data$admit )
#Create the confusion matrix with row-y_pred col=y
tab =table(y_pred,test.data$admit)
#There are 2 false positives and 15 false positives

