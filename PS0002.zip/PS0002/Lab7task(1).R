##Lab 7 task

setwd("/Users/shannamaeyang/Desktop/PS0002")

grad <-read.csv("gradadmit.csv", header = TRUE, sep=",")

dim(grad)
summary(grad)
str(grad)

#convert admit and rank into categorical variable
#factor(rank) allows us to compare effects between any two rank levels.
grad$admit <- factor(grad$admit)
grad$rank <- factor(grad$rank)

#split data#
set.seed(100)
training.idx <- sample(1: nrow(grad), size=nrow(grad)*0.8)
train.data  <-grad[training.idx, ]
test.data <- grad[-training.idx, ]

mlogit <- glm(admit ~., data = train.data, family = "binomial")
summary(mlogit)

#basedon the training data, the fitted logistic regression shows GPA and rank of institution
#are significant variables, while GRE is not significant.

#odds for 1 unit change in each variable
exp(coef(mlogit))
#interpretation:1 unit changes in non-significant variable GRE makes almost no changes in the P(Y=1)
#1 unit increase in GPA doubles the odds of being admitted 
#odds of being addmitted for applicants from rank2 (rank3, rank 4) institutions is 
#41% (23%, 17%) of that for applicants from highest prestige institution, respectively. 
####################
#Note: because factor(rank) is used and rank has 4 levels, R treats such a categorical variable 
#by generating 3 dummy (binary) variables: rank2, rank3 & rank4, 
#where level 1 is a baseline level, for i=2,3,4, ranki=1 (if rank=i) and =0 (otherwise).
#R use these 3 dummy variables to replace the original variable rank in the model,
#The estimated coefficient -0.89 of rank2 represents how ln(odds) changes when rank goes from the baseline level (level 1) to level 2 
#exp(-0.89)=41% indicates that odds of level2 is 41% of that of level 1. i.e., odds decreases by 59% from level 1 to level 2. 
#Similar for rank3 and rank 4.
#In this way, the comparison between any two rank levels can be done.
#If one directly uses variable rank, instead of factor(rank) in the model, such comparisons cannot be done from the output. 


#predicted probability P(Y=1)
Pred.p <-predict(mlogit, newdata =test.data, type = "response")
y_pred_num <-ifelse(Pred.p > 0.5, 1, 0)
y_pred <-factor(y_pred_num, levels=c(0, 1))
mean(y_pred ==test.data$admit )
table(y_pred,test.data$admit)

#Based on this logistic regressin model,  67.5% of applicants are correctly classified.

