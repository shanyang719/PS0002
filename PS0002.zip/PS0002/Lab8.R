setwd("/Users/shannamaeyang/Desktop/PS0002")
grad=read.csv("gradadmit.csv", header = TRUE, sep=",")
head(grad)
dim(grad)
#Step1: Prepare Data

grad<-grad%>%mutate(gre=as.numeric(gre), rank=as.numeric(rank))
##Normalize the numeric variables
nor <-function(x) { (x -min(x))/(max(x)-min(x)) }
grad[,2:4] <- sapply(grad[,2:4], nor)
##convert outcome admit to factor
grad$admit <- factor(grad$admit)
str(grad)
#Step 2: Split data
set.seed(100)
training.idx= sample(1: nrow(grad), size=nrow(grad)*0.8)
train.data=grad[training.idx, ]
test.data=grad[-training.idx, ]

#classification with k=3
library(class)
set.seed(101)
knn1<-knn(train.data[, 2:4], test.data[,2:4], train.data$admit, k=3) 
mean(knn1 ==test.data$admit )


#try different k to find the best classfier
ac<-rep(0, 30)
for(i in 1:30){
  set.seed(101)
  knn.i<-knn(train.data[,2:4], test.data[,2:4], cl=train.data$admit, k=i) 
  ac[i]<-mean(knn.i ==test.data$admit)
  cat("k=", i, " accuracy=", ac[i], "\n")
}
#Accuracy plot
plot(ac, type="b", xlab="K",ylab="Accuracy")
set.seed(101)
knn2<-knn(train.data[,2:4], test.data[,2:4], cl=train.data$admit, k=1)
mean(knn2 ==test.data$admit)

table(knn2,test.data$admit)

mlogit <- glm(admit~., data = train.data, family = "binomial")
#predicted probability P(Y=1)
Pred.p <-predict(mlogit, newdata =test.data, type = "response") 
y_pred_num <-ifelse(Pred.p > 0.5, 1, 0)
y_pred <-factor(y_pred_num, levels=c(0, 1))
mean(y_pred ==test.data$admit )
table(y_pred,test.data$admit )





mlogit <- glm(admit~., data = train.data, family = "binomial")
#predicted probability P(Y=1)
Pred.p <-predict(mlogit, newdata =test.data, type = "response") 
y_pred_num <-ifelse(Pred.p > 0.5, 1, 0)
y_pred <-factor(y_pred_num, levels=c(0, 1))
mean(y_pred ==test.data$admit )
table(y_pred,test.data$admit )







