##Solution for Assignment 2, normalization applies for kNN
##########################################################

library(mlbench)
library(dplyr)
library(class)
##1. prepare data
data(PimaIndiansDiabetes,package="mlbench")
?PimaIndiansDiabetes
str(PimaIndiansDiabetes)
summary(PimaIndiansDiabetes)
diab<-PimaIndiansDiabetes%>%mutate(y=factor(ifelse(diabetes=="pos",1,0)))%>%select(-diabetes)
str(diab)

##2.splitting data
set.seed(100)
training.idx <- sample(1: nrow(diab), size=nrow(diab)*0.8)
train.data  <-diab[training.idx, ]
test.data <- diab[-training.idx, ]

##3. (1)logistic regression (LR) using all 8 predictors
mlogit <- glm(y~., data = train.data, family = "binomial")
summary(mlogit)
#Five predictors: pregnant,glucose,pressure,mass,pedigree are significant at 0.05.

Pred.p <-predict(mlogit, newdata =test.data, type = "response")
Pred.p
y_pred <-factor(ifelse(Pred.p > 0.5, 1, 0))
mean(y_pred ==test.data$y )
#classification accuracy= 0.759740
#Confusion matrix
table(y_pred,actual=test.data$y)
#       actual
#y_pred  0  1
#     0 87 26
#     1 11 30
#Accuracy can also be computed from the confusion matrix by (87+30)/(87+30+11+26)=0.7597403
# false positive rate=11/(87+11)=11.2%
# false negative rate=26/(26+30)=46.4% 

##(2)kNN classification
##Normalize all numeric predictors
nor <-function(x) { (x -min(x))/(max(x)-min(x)) }
diab[,1:8] <- sapply(diab[,1:8], nor)
str(diab)
#splitting normalized data using the same training.idx as in LR, i.e., the same set of training/test individuals
train.data1  <-diab[training.idx, ] 
test.data1 <- diab[-training.idx, ]
str(test.data1)
##kNN classification
#Find value of k for the best classfier
ac<-rep(0, 30)
for(i in 1:30){
  set.seed(101)
  knn.i<-knn(train.data1[,1:8], test.data1[,1:8], cl=train.data1$y, k=i)
  ac[i]<-mean(knn.i ==test.data1$y) 
  cat("k=", i, " accuracy=", ac[i], "\n")
} 
#Accuracy plot
plot(ac, type="b", xlab="K",ylab="Accuracy")
#k=9 with highest accuracy=0.7727273
set.seed(101)
mknn<-knn(train.data1[,1:8], test.data1[,1:8], cl=train.data1$y, k=9)
mean(mknn ==test.data1$y) 
#[1] 0.7727273
#confusion matrix
table(pred_knn=mknn,actual=test.data1$y)
#          actual
#pred_knn  0  1
#       0 90 27
#       1  8 29
#Accuracy is slightly higher than that of logistic regression
# false positive rate=8/(90+8)=8.2%, smaller than that of LR
# false negative rate=27/(27+29)=48.2%  slightly bigger than that of LR

##(3)SVM classification
library(e1071)
m.svm<-svm(y~., data = train.data1, kernel = "linear")
summary(m.svm)
# predict
pred.svm <- predict(m.svm, newdata=test.data1[,1:8])

# Check accuracy:
table(predict=pred.svm, actual=test.data1$y)
#         actual
#predict  0  1
#      0 85 24
#      1 13 32
#misclassification rates: 
# false positive rate=13/(85+13)=13.3%, bigger than those of LR and kNN
# false negative rate=24/(24+32)=42.9%  smaller than both LR and kNN

mean(pred.svm ==test.data1$y)
#0.7597403 #same as the accuracy in LR classification but with different false positive rate

#Try radial kernel and tune its parameters 
set.seed(123) #tune requires random splitting for cross validation so set a seed
m.svm.tune1<-tune.svm(y~., data=train.data1, kernel="radial", cost=10^(-1:2), 
                      gamma=c(.1,.5,1,2))
summary(m.svm.tune1)
#classification performance
best.svm <- m.svm.tune1$best.model
pred.svm.tune <- predict(best.svm, newdata=test.data1[,1:8])
table(pred.svm.tune, test.data1$y)
mean(pred.svm.tune ==test.data1$y)
# 0.7012987, not as good as linear kernel SVM

##Or you can use sigmoid kernel #
#Try sigmoid kernel and tune its parameters, but it doesn't improve performance.
set.seed(121)
m.svm.tune2<-tune.svm(y~., data=train.data1, kernel="sigmoid", gamma=c(0.1,0.5,1,2,3,4), coef0=c(0.1,0.5,1,2,3,4))
summary(m.svm.tune2)
#performance
best.svm <- m.svm.tune2$best.model
pred.svm.tune <- predict(best.svm, newdata=test.data1[,1:8])
table(pred=pred.svm.tune, actual=test.data1$y)
mean(pred.svm.tune ==test.data1$y)
#Accuracy = 0.7597403 same as the linear kernel one.
#Therefore, we use the linear kernel SVM to compare with LR and kNN

##(4) Comparison between LR, kNN and SVM
#In terms of accuracy, 3 methods perform similarly well. 
#With currently used seeds, kNN classification with k=9 is slightly better (more accurate) than LR and SVM. 
#Misclassification rates include the false positive rate and false negative rate.
#In the diabetes test, a small false negative rate is more desirable than a small false positive rate 
#because failure of identifying an actual diabetes patients is worse than false alarm (positive).   
#Therefore, in terms of false negative rate, svm classification with linear kernel performs the best. 

############################################################################################# 
##Alternative way 1.
##The normalization step can be done simply before logistic regression. All LR, kNN and SVM methods use the normalized data.
##Results will be the same as those given above.
##1. prepare data with normalization
data(PimaIndiansDiabetes,package="mlbench")
str(PimaIndiansDiabetes)
summary(PimaIndiansDiabetes)
diab<-PimaIndiansDiabetes%>%mutate(y=factor(ifelse(diabetes=="pos",1,0)))%>%select(-diabetes)
##Normalize all numeric predictors
nor <-function(x) { (x -min(x))/(max(x)-min(x)) }
diab[,1:8] <- sapply(diab[,1:8], nor)
str(diab) 
##2.splitting data
set.seed(100)
training.idx <- sample(1: nrow(diab), size=nrow(diab)*0.8)
train.data  <-diab[training.idx, ]
test.data <- diab[-training.idx, ]
##3. Perform glm(), knn() and svm() based on the train.data and test.data.

############################################################################################# 
##Alternative way 2.
##The kNN classification can be done using function train() available in package caret.
##Then no need to write any code for data normalization as it is done by default in train().
##The best value of k obtained by train() depends on the values of fold numbers in "cv" and tuneLength.
##Sometimes the best k value is different from the result obtained by knn() together with a loop for k. 
##1. prepare data
data(PimaIndiansDiabetes,package="mlbench")
str(PimaIndiansDiabetes)
summary(PimaIndiansDiabetes)
diab<-PimaIndiansDiabetes%>%mutate(y=factor(ifelse(diabetes=="pos",1,0)))%>%select(-diabetes)

##2.splitting data
set.seed(100)
training.idx <- sample(1: nrow(diab), size=nrow(diab)*0.8)
train.data  <-diab[training.idx, ]
test.data <- diab[-training.idx, ]

##3. (1)logistic regression using all 8 predictors
mlogit <- glm(y~., data = train.data, family = "binomial")
summary(mlogit)
Pred.p <-predict(mlogit, newdata =test.data, type = "response")
Pred.p
y_pred <-factor(ifelse(Pred.p > 0.5, 1, 0))
mean(y_pred ==test.data$y )
#classification accuracy= 0.759740
table(y_pred,actual=test.data$y)

##(2)kNN classification
library(caret)
mknn<-train(y~., data = train.data, method = "knn", 
 trControl = trainControl("cv", number = 10), 
 preProcess = c("center","scale"),tuneLength=10)
mknn$bestTune #k=21
pred.knn <- predict(mknn, newdata=test.data)
mean(pred.knn ==test.data$y) 
#[1] 0.7597403 #same as that in logistic regression
#confusion matrix
table(pred_knn=pred.knn,actual=test.data$y)
#         actual
#pred_knn  0  1
#       0 92 31
#       1  6 25

##(3)SVM classification
library(e1071)
m.svm<-svm(y~., data = train.data, kernel = "linear")
summary(m.svm)
# predict
pred.svm <- predict(m.svm, newdata=test.data[,1:8])
mean(pred.svm ==test.data$y)
table(predict=pred.svm, actual=test.data$y)

 
