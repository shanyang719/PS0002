setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
library(ggplot2)

#Question 2
#Part i
data("Boston",package="MASS")
head(Boston)
colnames(Boston)
Boston
help("Boston",package="MASS")
Boston=Boston%>%filter(20<age,age<100)
#%>%select(-c(zn,indus,chas,age,rad,tax,black))

Boston

set.seed(100)
training.idx=sample(1:nrow(Boston),nrow(Boston)*0.8)
train.data=Boston[training.idx,]
test.data=Boston[-training.idx,]

nrow(train.data)
colnames(Boston)

library(caret)
set.seed(101)
model=train(medv~crim+nox+rm+dis+ptratio+lstat,data=train.data, method="knn",trControl=trainControl("cv",number=7),preProcess=c("center","scale"),tuneLength=10)
plot(model)
model$bestTune
#k=5

#Step 5: Assess prediction perfprmance of KNN regression on the test data set
predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$medv)
# iia) k=5 RMSE=3.419986
plot(test.data$medv,predictions,main="Prediction performance of kNN regression")
abline(0,1,col="red")





# iia)
#PART A k=5 RMSE=3.419986
#PART B: rm,ptratio and lstat are hightly significant predictors
#PART C: Adjusted R-squared:  0.7537 is high so the model explains a high percentage of the dependent variable (medv) variation
#PART D: I would choose the KNN model since the RMSE value of 3.419986 is lower than that of linear regression model with RMSE value=3.672291. This means that the KNN model has less error
#PART E: improve linear regression model by removing outliers 321,321,322. re-train linear model with the new dataset as shown below

colnames(Boston)

#step 2: Linear Regression Model
lmodel=lm(medv~crim+nox+rm+dis+ptratio+lstat,data=train.data)
summary(lmodel)

#Step 3: Interpretation
predictions=predict(lmodel,test.data)
head(predictions)
plot(test.data$medv,predictions,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions,test.data$medv)
# RMSE value=4.175943
#PART C: Adjusted R-squared:  0.7537 is high so the model explains a high percentage of the dependent variable (medv) variation

#Step 4: Look at the residuals
par(mfrow=c(2,2))
plot(lmodel)
#Outliers are 320,321,322

#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)
#PART B: rm,ptratio and lstat are hightly significant predictors

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(medv~crim+nox+rm+dis+ptratio+lstat+I(rm^2)+I(lstat^2)+I(ptratio^2),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$medv)
plot(p2model)
#PART E: improve linear regression model by removing outliers 321,321,322. re-train linear model with the new dataset as shown below
Boston1=Boston[-c(320,321,322),]
set.seed(100)
training.idx=sample(1:nrow(Boston1),size=nrow(Boston1)*0.8)
train.data=Boston1[training.idx,]
test.data=Boston1[-training.idx,]

                  

#PART D: I would choose the KNN model since the RMSE value of 3.419986 is lower than that of linear regression model with RMSE value=3.672291. This means that the KNN model has less error


