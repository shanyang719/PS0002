setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
library(ggplot2)
library(corrplot)

summary(marketing)
pairs.panels(marketing,method="pearson", hist.col="steelblue",pch=21,,density=TRUE,ellipses=FALSE)

ggplot(marketing,aes(x=sales,y=youtube))+geom_bar(stat="identity")


#split the data
set.seed(100)
training.idx=sample(1:nrow(marketing),nrow(marketing)*0.8)
train.data=marketing[training.idx,]
test.data=marketing[-training.idx,]

#Step 4: Fit the model
library(caret)
set.seed(101)
model=train(sales~.,data=train.data, method="knn",trControl=trainControl("cv",number=4),preProcess=c("center","scale"),tuneLength=10)
plot(model)
model$bestTune

#Step 5: Assess prediction perfprmance of KNN regression on the test data set
predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$sales)
plot(test.data$sales,predictions,main="Prediction performance butt")
abline(0,1,col="red")







lmodel=lm(sales~.,data=train.data)
summary(lmodel)

#Step 3: Interpretation
predictions2=predict(lmodel,test.data)
head(predictions2)
plot(test.data$sales,predictions2,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions2,test.data$sales)

#Step 4: Look at the residuals
par(mfrow=c(2,2))
plot(lmodel)


#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)

#Step 6: remove outliers
marketing1=marketing[-c(131),]
set.seed(100)
training.idx=sample(1:nrow(marketing1),size=nrow(marketing1)*0.8)
train.data=marketing1[training.idx,]
test.data=marketing1[-training.idx,]

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(sales~youtube+facebook+newspaper+I(youtube^2)+I(facebook^2),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$sales)
plot(p2model)    

p2model=lm(sales~youtube+facebook+newspaper+I(youtube^2)+I(facebook^2)+I(youtube*facebook),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$sales)
plot(p2model) 
