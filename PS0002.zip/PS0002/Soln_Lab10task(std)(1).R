#download dataset computers.csv from NTULearn
library(dplyr)
setwd("/Users/shannamaeyang/Desktop/PS0002")
comp <-read.csv("computers.csv", header = TRUE, sep=",")
str(comp)
comp1 <- comp%>%select(price, speed, hd, ram, screen, ads, trend)%>%
  mutate(price_scal = scale(price), speed_scal = scale(speed),
         hd_scal = scale(hd),
         ram_scal = scale(ram),
         screen_scal = scale(screen),
         ads_scal = scale(ads),
         trend_scal = scale(trend))%>%
  select(-c(price, speed, hd, ram, screen, ads, trend))
str(comp1)
# 3 initial clusters
k3 <- kmeans(comp1, centers = 3, nstart = 25)
str(k3)
k3 #between_SS/total_SS=38.8%
#optimal k
set.seed(100)
## function to compute total within-cluster sum of square 
wcss <- function(k) {
  kmeans(comp1, k, nstart = 10 )$tot.withinss
}

# Compute and plot wss for k = 1 to k = 30
k.values <- 1:30
# apply wcss to all k values
wcss_k<-sapply(k.values, wcss)
plot(k.values, wcss_k,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

# or plot the graph using gglop
library(ggplot2)
#create a dataframe for ggplot
elbow<-data.frame(k.values, wcss_k)
ggplot(elbow, aes(x = k.values, y = wcss_k)) +
  geom_point() +
  geom_line() +
  scale_x_continuous(breaks = seq(1, 30, by = 1))
#select the elbow point k=7
set.seed(100)
k7 <- kmeans(comp1, centers = 7, nstart = 10)
str(k7)
k7 #between_SS/total_SS=63.1%. Greater this ratio, more distinct the clustering. 
#summarize means at cluster level
comp %>% select(price, speed, hd, ram, screen, ads, trend)%>%mutate(Cluster = k7$cluster) %>% 
  group_by(Cluster) %>% summarise_all("mean")

## Hierarchical clustering using Complete Linkage
hc1 <- hclust(dist(comp1), method = "complete" )
# Plot the obtained dendrogram
plot(hc1, cex = 0.6, hang =-.1)
#draw rectangles with different colors for 7 clusters respectively in the dendrogram, 
#where argument border specifies the colors of the rectangles, default value of border=1 for black.
rect.hclust(hc1, k=7, border = 2:8)

