setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
library(dplyr)
library(ggplot2)
library (nycflights13)
library(psych)
print(flights)
colnames(flights)
flights%>%group_by(carrier)%>%
  summarise(ave_delay=mean(dep_delay, na.rm=TRUE))%>%
  ggplot(aes(x=carrier,y=ave_delay))+geom_bar(stat='identity')
flights%>%group_by(carrier)%>%ggplot(aes(x=carrier,y=dep_delay))+geom_boxplot()+ylim(0,100)
flights%>%filter(carrier%in%c("EV","OO","YV"))%>%group_by(carrier)%>%ggplot(aes(x=carrier,y=dep_delay))+geom_boxplot()+ylim(0,100)
flights%>%filter(carrier%in%c("EV","OO","YV"))%>%
  ggplot(aes(x=origin,y=dep_delay,fill=carrier))+geom_boxplot()+ylim(0,100)
ggplot(flights,aes(air_time,fill=origin))+geom_histogram(bins=60,na.rm=TRUE)
ggplot(flights,aes(air_time))+geom_density()
ggplot(flights,aes(air_time))+geom_histogram(bins=60,aes(y=..density..),colour="black",fill="white",na.rm=TRUE)+geom_density(alpha=0.2,fill="pink")
dist_time=flights%>%filter(carrier%in%c("UA","AA"),air_time>550)
ggplot(na.omit(dist_time),aes(x=air_time,y=dep_delay,col=carrier))+geom_point()+geom_smooth()
colnames(iris)
ggplot(iris,aes(x=Sepal.Length,y=Petal.Length,col=Species))+geom_point()

pairs(iris[1:4], main = "Iris Data -- 3 species", pch = 21,
      bg = c("pink", "lightgreen", "lightblue") [unclass(iris$Species)])
pairs.panels(iris[,-5],method="pearson", hist.col="steelblue", pch=21, bg=c("pink" , "light green","light blue")[(iris$Species)],density=TRUE,ellipses=FALSE)

cor(iris[,-5])
