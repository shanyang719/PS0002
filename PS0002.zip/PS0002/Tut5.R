setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
install.packages("MASS")
install.packages("caret")
library(dplyr)
library(ggplot2)
data("Boston",package="MASS")

#Step 2: check the data and calculating data summary
head(Boston)
dim(Boston)
summary(Boston)
colnames(Boston)

#Step 3: split the data into training and test sets
set.seed(100)
training.idx=sample(1:nrow(Boston),nrow(Boston)*0.8)
train.data=Boston[training.idx,]
test.data=Boston[-training.idx,]

#Step 4: Fit the model
library(caret)
set.seed(101)
model=train(medv~age,data=train.data, method="knn",trControl=trainControl("cv",number=10),preProcess=c("center","scale"),tuneLength=10)
plot(model)
model$bestTune

#Step 5: Assess prediction perfprmance of KNN regression on the test data set
predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$medv)
plot(test.data$medv,predictions,main="Prediction performance butt")
abline(0,1,col="red")
