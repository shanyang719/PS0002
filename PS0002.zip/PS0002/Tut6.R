setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
library(ggplot2)
install.packages("corrplot")

colnames(Boston)

#Step 1: create training set and teszt set
set.seed(100)
training.idx=sample(1:nrow(Boston),nrow(Boston)*0.8)
train.data=Boston[training.idx,]
test.data=Boston[-training.idx,]

#step 2: Linear Regression Model
lmodel=lm(medv~.,data=train.data)
summary(lmodel)

#Step 3: Interpretation
predictions=predict(lmodel,test.data)
head(predictions)
plot(test.data$medv,predictions,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions,test.data$medv)

#Step 4: Look at the residuals
par(mfrow=c(2,2))
plot(lmodel)


#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)

#Step 6: remove outliers
Boston1=Boston[-c(369,373,413),]
set.seed(100)
training.idx=sample(1:nrow(Boston1),size=nrow(Boston1)*0.8)
train.data=Boston1[training.idx,]
test.data=Boston1[-training.idx,]

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+black+lstat+I(rm^2)+I(ptratio^2)+I(lstat^2)+I(indus^2),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$medv)
plot(p2model)                  

