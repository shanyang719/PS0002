setwd("/Users/shannamaeyang/Desktop/PS0002")

install.packages("dplyr")
install.packages("mlbench")
library(dplyr)
data(BreastCancer,package="mlbench")
str(BreastCancer)
head(BreastCancer)

#Step1: Prepare Data
bc=BreastCancer[complete.cases(BreastCancer),]
dim(bc)
bc[,2:4]= sapply(bc[,2:4], as.numeric)
bc=bc%>%mutate(y=factor(ifelse(Class=="malignant",1,0)))%>%select(Cl.thickness:Cell.shape,y)
str(bc)

#Step 2: Split data
set.seed(100)
training.idx= sample(1: nrow(bc), size=nrow(bc)*0.8)
train.data=bc[training.idx, ]
test.data=bc[-training.idx, ]

#Step 3: Logistic Regression Model

mlogit= glm(y~Cl.thickness+Cell.size+Cell.shape,data=train.data,family="binomial")
summary(mlogit)

#Step 4: Predict
Pred.p =predict(mlogit, newdata =test.data, type = "response")

y_pred_num =ifelse(Pred.p > 0.5, 1, 0)
y_pred =factor(y_pred_num, levels=c(0, 1))
#Accuracy of the classification
mean(y_pred ==test.data$y )
#Create the confusion matrix with row-y_pred col=y
tab =table(y_pred,test.data$y)
