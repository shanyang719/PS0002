setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
install.packages("mlbench")
install.packages("class")
library(dplyr)
data(BreastCancer,package="mlbench")
bc <-BreastCancer[complete.cases(BreastCancer),]
bc[,2:4]<- sapply(bc[,2:4], as.numeric) 
bc<-bc%>%mutate(y=factor(ifelse(Class=="malignant", 1,0)))%>%select(Cl.thickness:Cell.shape, y)
#Normalize numeric variables
nor <-function(x) { (x -min(x))/(max(x)-min(x)) }
bc[,1:3] <- sapply(bc[,1:3], nor)
#split data
set.seed(100)
training.idx <- sample(1: nrow(bc), size=nrow(bc)*0.8)
train.data  <-bc[training.idx, ]
test.data <- bc[-training.idx, ]
#kNN classification
library(class)
set.seed(101)
knn1<-knn(train.data[,1:3], test.data[,1:3], cl=train.data$y, k=2) 
mean(knn1 ==test.data$y)
table(knn1,test.data$y)



gc <-read.csv("germancredit.csv", header = TRUE, sep=",") 
dim(gc)

str(gc)
#convert outcome default to factor(categorical variable)
gc$Default <- factor(gc$Default)
#Find those numeric variables (T/F)
numvar<- sapply(gc, is.numeric)
#Normalize 7 numeric variables
nor <-function(x) { (x -min(x))/(max(x)-min(x)) }
gc[,numvar] <- sapply(gc[,numvar], nor)
#For a simple illustration, select only first 3 numeric variables
gc1 <- gc%>%select("Default","duration", "amount", "installment")
#split data
set.seed(100)
training.idx <- sample(1: nrow(gc1), size=nrow(gc1)*0.8)
train.data  <-gc1[training.idx, ]
test.data <- gc1[-training.idx, ]

#classification with k=3
library(class)
set.seed(101)
knn1<-knn(train.data[, 2:4], test.data[,2:4], train.data$Default, k=3) 
mean(knn1 ==test.data$Default )


#try different k to find the best classfier
ac<-rep(0, 30)
for(i in 1:30){
  set.seed(101)
  knn.i<-knn(train.data[,2:4], test.data[,2:4], cl=train.data$Defaul, k=i) 
  ac[i]<-mean(knn.i ==test.data$Default)
  cat("k=", i, " accuracy=", ac[i], "\n")
}
#Accuracy plot
plot(ac, type="b", xlab="K",ylab="Accuracy")
set.seed(101)
knn2<-knn(train.data[,2:4], test.data[,2:4], cl=train.data$Default, k=14)
mean(knn2 ==test.data$Default)

table(knn2,test.data$Default)

mlogit <- glm(Default~., data = train.data, family = "binomial")
#predicted probability P(Y=1)
Pred.p <-predict(mlogit, newdata =test.data, type = "response") 
y_pred_num <-ifelse(Pred.p > 0.5, 1, 0)
y_pred <-factor(y_pred_num, levels=c(0, 1))
mean(y_pred ==test.data$Default )
table(y_pred,test.data$Default )

