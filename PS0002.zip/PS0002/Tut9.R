setwd("/Users/shannamaeyang/Desktop/PS0002")
#install.packages("dplyr")
#install.packages("mlbench")
#install.packages("e1071")
library(dplyr)
data(BreastCancer,package="mlbench")
bc <-BreastCancer[complete.cases(BreastCancer),]
bc[,2:4]<- sapply(bc[,2:4], as.numeric) 
str(bc)
bc<-bc%>%mutate(y=factor(ifelse(Class=="malignant", 1,0)))%>%select(Cl.thickness:Cell.shape, y)
#split data
set.seed(100)
training.idx <- sample(1: nrow(bc), size=nrow(bc)*0.8)
train.data <-bc[training.idx, ]
test.data <- bc[-training.idx, ]
# SVM classification, install package e1071
library(e1071)
m.svm<-svm(y~Cl.thickness+Cell.size+Cell.shape, data = train.data,kernel = "linear")

summary(m.svm)



#predict newdata in test set
pred.svm <- predict(m.svm, newdata=test.data[,1:3])
#evaluate classification performance and check accuracy
table(pred.svm, test.data$y)
mean(pred.svm ==test.data$y)

#TUNING
#Set a seed for reproducing results
set.seed(123)
m.svm.tune<-tune.svm(y~., data=train.data, kernel="radial",cost=10^(-1:2), gamma=c(.1,.5,1,2)) 
summary(m.svm.tune)


#visualize results of parameter tuning
plot(m.svm.tune)
#confusion matrix and accuracy
best.svm = m.svm.tune$best.model
pred.svm.tune = predict(best.svm, newdata=test.data[,1:3]) 
table(pred.svm.tune, test.data$y)

mean(pred.svm.tune ==test.data$y)


