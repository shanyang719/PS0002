setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
data(PimaIndiansDiabetes,package="mlbench")
dia=PimaIndiansDiabetes[complete.cases(PimaIndiansDiabetes),]
head(PimaIndiansDiabetes)
dim(dia)
dia[,1:8]= sapply(dia[,1:8], as.numeric) 
##Normalize the numeric variables
nor =function(x) { (x -min(x))/(max(x)-min(x)) }
dia[,1:8] = sapply(dia[,1:8], nor)
dia=dia%>%mutate(Y=factor(ifelse(diabetes=="pos", 1,0)))%>%select(pregnant:age, Y)
#Since assignment asks to perform classification using all 8 predictor, select all predictors: pregnant, gluocse, pressure, triceps, insulin, mass, pedigree and age for classification
#split data
set.seed(100)
training.idx=sample(1: nrow(dia), size=nrow(dia)*0.8)
train.data=dia[training.idx, ]
test.data=dia[-training.idx, ]


#Logistic Regression Model
mlogit= glm(Y~.,data=train.data,family="binomial")
summary(mlogit)

mlogit= glm(Y~.,data=train.data,family="binomial")
#Predict
Pred.p =predict(mlogit, newdata =test.data, type = "response")
y_pred_num =ifelse(Pred.p > 0.5, 1, 0)
y_pred =factor(y_pred_num, levels=c(0, 1))
#Accuracy of the classification
mean(y_pred ==test.data$Y )
#[1] 0.7597403
#Create the confusion matrix with row-y_pred col=y
table(y_pred,test.data$Y)
#y_pred  0  1
#0 87 26
#1 11 30
#Accuracy= 76.0%
#False Positive Rate=11/(11+87)=0.11
#False Negative Rate= 26/(26+30)=0.46


#kNN
#classification with k=3
library(class)
set.seed(101)
knn1=knn(train.data[, 1:8], test.data[,1:8], train.data$Y, k=3) 
mean(knn1 ==test.data$Y )
#[1] 0.7207792
#try different k to find the best classfier
ac=rep(0, 30)
for(i in 1:30){
  set.seed(101)
  knn.i<-knn(train.data[,1:8], test.data[,1:8], cl=train.data$Y, k=i) 
  ac[i]=mean(knn.i ==test.data$Y)
  cat("k=", i, " accuracy=", ac[i], "\n")
}
#Accuracy plot
plot(ac, type="b", xlab="K",ylab="Accuracy")
#Choose k=29
set.seed(101)
knn2=knn(train.data[,1:8], test.data[,1:8], cl=train.data$Y, k=29)
mean(knn2 ==test.data$Y)
#[1] 0.7727273
table(knn2,test.data$Y)
#knn2  0  1
#0 91 28
#1  7 28
#Accuracy= 77.3%
#False Positive Rate=7/(7+91)
#False Negative Rate= 28/(28+28)=0.5


# SVM classification, install package e1071
library(e1071)
m.svm=svm(Y~., data = train.data,kernel = "linear")

summary(m.svm)



#predict new data in test set
pred.svm = predict(m.svm, newdata=test.data[,1:8])
#evaluate classification performance and check accuracy
table(pred.svm, test.data$Y)
mean(pred.svm ==test.data$Y)
#[1] 0.7597403
#pred.svm  0  1
#0 85 24
#1 13 32
#Accuracy= 76.0%
#False Positive Rate=13/(13+85)
#False Negative Rate=24/(24+32)


#Tuning SVM
set.seed(123)
m.svm.tune=tune.svm(Y~., data=train.data, kernel="radial",cost=10^(-1:2), gamma=c(.1,.5,1,2)) 
summary(m.svm.tune)


#visualize results of parameter tuning
plot(m.svm.tune)
#confusion matrix and accuracy
best.svm = m.svm.tune$best.model
pred.svm.tune = predict(best.svm, newdata=test.data[,1:8]) 
table(pred.svm.tune, test.data$Y)

mean(pred.svm.tune ==test.data$Y)
#[1] 0.7012987
#pred.svm.tune  0  1
#0 86 34
#1 12 22
#Accuracy= 70.1%
#False Positive Rate=12/(12+86)
#False Negative Rate=34/(34+22)
#Choose kernel="linear" for SVM



#Logistic regression (choose all 8 predictors as requested in assignment)
#Accuracy= 76.0%
#False Positive Rate=11/(11+87)=0.11
#False Negative Rate= 26/(26+30)=0.46

#knn (k=29)
#Accuracy= 77.3%
#False Positive Rate=7/(7+91)=0.071
#False Negative Rate= 28/(28+28)=0.50

#svm (Best=linear) 
#Accuracy= 76.0%
#False Positive Rate=13/(13+85)=0.13
#False Negative Rate=24/(24+32)=0.43


#Comparing Accuracy of the 3 methods: 
# KNN has the highest accuracy at 77.3% followed by Logistic regression and SVM which both have an accuracy of 76.0%

#Comparing False Positive Rate:
#KNN has the lowest false positive rate at 0.071 followed by Logistic regresstion at 0.11 and SVM at 0.13

#Comparing False Negative Rate: 
#SVM has the lowest false negative rate at 0.43 followed closely by logistic regression at 0.46 and KNN at 0.50

#Overall, KNN is the best model as it has the highest accuracy and lowest false postive rate. Although its false negative rate is the highest of the 3 models, it is only marginally higher than that of SVM.