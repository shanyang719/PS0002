#download datafiles ex1ar.txt and ex2.txt to working directory
#Lecture Notes 03 slides 8-12 
ex1<-read.table ("ex1ar.txt", header=T) 
ex1ar <- ex1[,1] 
summary(ex1ar) 
length(ex1ar)
mean(ex1ar)
median(ex1ar)
min(ex1ar); max(ex1ar)
range(ex1ar)
quantile(ex1ar)
var(ex1ar)
sd(ex1ar)
IQR(ex1ar)
cv <- function(x) sd(x)/mean(x)*100
cv(ex1ar)
ex2.1ar[order(ex2.1ar)[1:5]] # smallest 5 observations
nar <- length(ex1ar)
ex1ar[order(ex1ar)[(nar-4):nar]] #
skew <- function(x){
  n <- length(x)
  m2 <- sum((x-mean(x))^2)/n
  m3 <- sum((x-mean(x))^3)/n
  m3/m2^(3/2)*sqrt(n*(n-1))/(n-2)
}
skew(ex1ar)
kurtosis<- function(x){
  n <- length(x)
  m2 <- sum((x-mean(x))^2)/n
  m4 <- sum((x-mean(x))^4)/n
  (n-1)/((n-2)*(n-3))*((n+1)*m4/m2^2-3*(n-1))
}
kurtosis(ex1ar)

#slide 15
hist(ex1ar, include.lowest=TRUE, freq=TRUE, main=paste("Histogram of return"), xlab="return", ylab="frequency", axes=TRUE) 
# Normal curve imposed on the histogram 
xpt<-seq(-10,100,0.1) 
ypt<-dnorm(seq(-10,100,0.1),mean(ex1ar),sd(ex1ar))
ypt<-ypt*length(ex1ar)*10
lines(xpt,ypt)
#slides 22,28-29
qqnorm(ex1ar)
qqline(ex1ar)
stem(ex1ar) 
boxplot(ex1ar) 

#slides 32-35
ex2<-read.table("ex2.txt",  header=T)
attach(ex2) 
ex2ar<-ex2[Risk==1,"Return"]
ex2hr<-ex2[Risk==2,"Return"]
summary(ex2hr) 
stem(ex2hr) 
boxplot(Return~Risk) 
