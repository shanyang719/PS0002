
lab1=read.fwf("lab1fixed.txt",width=c(3,1,3,2,1))
View(lab1)
varnames=c("id","gender","weight","height","siblings")
lab1=read.fwf("lab1fixed.txt",width=c(3,1,3,2,1), col.names=varnames)
lab1$gender
lab1$gender=="M"
lab1[gender=="M",]
nrow(lab1)
attach(lab1)
names(lab1)
detach(lab1)
names(lab1)
lab1[gender=="M",]
lab1m=lab1[gender=="M",]
