#task 1
setwd("/Users/shannamaeyang/Desktop/PS0002")
varnames=c("id","gender","height","weight","siblings")
lab1=read.fwf("lab1fixed.txt",width=c(3,1,3,2,1), col.names=varnames)
View(lab1test)
lab1m=lab1[gender=="M",]
nrow(lab1m)
lab1test=read.table("lab1test.txt",header=TRUE)
lab1merge=merge(lab1,lab1test)
lab1tall=lab1merge[lab1merge$height>182,]
lab1remo=lab1merge[-11,]
lab1merge[11,4]=80
lab1f=lab1merge[lab1merge$gender=="F",]
lab1f=lab1f[rev(order(lab1f$height)),]
sectallestF=lab1f[2,]

#task 2
x=c(1,1,1,1,1,3,5,7)
dim(x)=c(4,2)
y=c(4,6,13,20)
dim(y)=c(4,1)
beta=solve(t(x)%*%x)%*%t(x)%*%y

#task 3
m1=sum(lab1$height)/nrow(lab1)
m2=0
for(i in lab1$height){
  m2=m2+(i-m1)^2
}
m2=m2/120

m3=0
for(i in lab1$height){
  m3=m3+(i-m1)^3
}
m3=m3/120

m4=0
for(i in lab1$height){
  m4=m4+(i-m1)^4
}
m4=m4/120

#task 4:Write a program to find the root within [-4, 0] of function f(x) 
#given in slide 55 of Notes (Introduction to R) using the bisection algorithm 
#in slide 56.

f=function(z){
  ycoord=(-2*z^2)-5*z+7
  return(ycoord)
}

xmin=-4
xmax=0

while(f(xmid)!=0){
  xmid=(xmin+xmax)/2
  if(f(xmin)*f(xmid)<0){
    xmin=xmin
    xmax=xmid
  }else{
    xmin=xmid
    xmax=xmax
  }
}
cat(xmid,f(xmid))
  
