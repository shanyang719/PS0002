setwd("/Users/shannamaeyang/Desktop/PS0002")
library(dplyr)
library (nycflights13)
print (flights)
print(planes)
print(weather)
print(airlines)
print(airports)
head(flights)



ordered=flights[order(flights$carrier),]
print(ordered)

airports%>%filter(faa%in%c('ALB','BDL','BTV'))

bycarrier= flights%>%group_by(carrier)
bycarrier
Delay<- summarise(bycarrier, count=n(), dist=mean(distance, na.rm=TRUE), delay=mean(dep_delay, na.rm=TRUE))
Delay

summarise(flights, count=n())

flights%>%summarise(numflights=n())

monthlycounts=flights%>%
  filter(dest%in%c("ALB", "BDL","BTV")) %>%
  group_by(year,month) %>%
  summarise(numflights=n())
monthlycounts
airportmonthlycounts=flights%>%
  filter(dest%in%c("ALB", "BDL","BTV")) %>%
  group_by(year,month,dest)%>%
  summarise(numflights=n())
airportmonthlycounts
library(lubridate)
airportdailycounts=flights%>%
  filter(dest%in%c("ALB", "BDL","BTV")) %>%
  group_by(year,month,day,dest)%>%
  summarise(numflights=n())%>%
  mutate(date=ymd(paste(year,month,day, sep="-")))
airportdailycounts
library(ggplot2)
ggplot(data=airportdailycounts, aes(x=date, y=numflights, colour=dest)) +geom_point()

airportmonthlycounts=airportmonthlycounts %>%
  mutate(FirstOfMonth=ymd(paste(year, "-",month,"-01",sep=" ")))
ggplot(data=airportmonthlycounts, aes(x=FirstOfMonth, y=numflights, colour=dest)) +geom_point()

colnames(flights)

airportmonthlycounts%>% arrange(desc(numflights))
jandelays=flights%>%select(origin,dest,year,month,day,carrier,arr_delay)%>%
  filter(dest=="MSP" &month==1)
ggplot(data=jandelays,aes(x=carrier,y=arr_delay))+geom_boxplot()

merged=left_join(jandelays,airlines,by=("carrier"="carrier"))
merged

flights%>%filter(dest=="ORD")%>%summarise(count=n())
flights%>%filter(dest=="YYZ")%>%summarise(count=n())
