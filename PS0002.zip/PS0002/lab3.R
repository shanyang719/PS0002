setwd("/Users/shannamaeyang/Desktop/PS0002")
install.packages("dplyr")
library(dplyr)
library(ggplot2)

#Part 1
data(msleep)
summary(msleep)
dim(msleep)
sleep2=msleep%>%
  select(vore:bodywt)%>%
  select(-conservation)%>%
  filter(brainwt<0.015)


#Part 2
sleep2=sleep2%>%mutate(sleep2,rem_percentage=(sleep_rem/sleep_total)*100)
head(sleep2)
colnames(sleep2)
sleep2=sleep2%>%mutate(sleep2,cycles=(sleep_total/sleep_cycle))

#Part 3
byvore=group_by(sleep2,vore)
Averages= summarise(byvore, count=n(), average_rem=mean(rem_percentage, na.rm=TRUE), average_cycles=mean(cycles, na.rm=TRUE))
Averages
summary(Averages)
arrange(Averages,average_rem)
#Herbivores have the lowest average percentage of rem sleep at an average of 13.6%
#Omnivores have the highest average percentage of rem sleep at an average of 21.5%
arrange(Averages,average_cycles)
#Carnivores have the lowest average number of cycles at 45.4 cycles
#Insectivores have the highest average number of cycles at 106 cycles

#Part 4
ggplot(sleep2, aes(x=vore, y=rem_percentage)) +geom_boxplot()
#We ignore the percentage of rem sleep of Carnivores and Insectivores because the sample size is too small
#Omnivores have a greater range of percentage of rem sleep than Herbivores

#Part 5
ggplot(sleep2, aes(x=rem_percentage, y=cycles))+geom_point()+geom_smooth(method="lm")
#As percentage of rem sleep increases, the number of cycles decreases
