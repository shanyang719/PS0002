setwd("/Users/shannamaeyang/Desktop/PS0002/Week2")
library(dplyr)

head(read.csv("msleep_ggplot2",header=FALSE))
read.csv("msleep_ggplot2.csv",header=TRUE)%>%head
head(read.table("msleep_ggplot2.csv",header=TRUE))
read.table("msleep_ggplot2.csv",header=TRUE,sep=",")%>%head


library(ggplot2)
library (nycflights13)
colnames(flights)
head(flights)
ncol(flights)
w1=flights[flights$month==3,1:17]
w2=flights[flights$month==3,-c(distance:time_hour)]
w3=flights%>%select(year:hour)%>%filter(month==3)
w4=flights%>%filter(month==3)%>%select(-c(minute:time_hour))
ncol(w2)
w1==w2
colnames(flights)
flights%>%ggplot(aes(x=air_time,y=distance,col=carrier))+geom_point()+geom_smooth()

data("Boston",package="MASS")
head(Boston)

colnames(Boston)
Boston=Boston%>%filter(indus>3,age>30)

set.seed(100)
training.idx=sample(1:nrow(Boston),nrow(Boston)*0.8)
train.data=Boston[training.idx,]
test.data=Boston[-training.idx,]

nrow(train.data)
colnames(Boston)

library(caret)
set.seed(101)
model=train(medv~crim+nox+rm+dis+rad+tax+ptratio+lstat,data=train.data, method="knn",trControl=trainControl("cv",number=8),preProcess=c("center","scale"),tuneLength=10)
plot(model)
model$bestTune

#Step 5: Assess prediction perfprmance of KNN regression on the test data set
predictions=predict(model,test.data)
head(predictions)
RMSE(predictions,test.data$medv)
#3.093696
plot(test.data$medv,predictions,main="Prediction performance of kNN regression")
abline(0,1,col="red")
##Very inaccurate prediction








colnames(Boston)

#step 2: Linear Regression Model
lmodel=lm(medv~crim+nox+rm+dis+rad+tax+ptratio+lstat,data=train.data)
summary(lmodel)

#Step 3: Interpretation
predictions=predict(lmodel,test.data)
head(predictions)
plot(test.data$medv,predictions,main="Prediction performance butt")
abline(0,1,col="red")
RMSE(predictions,test.data$medv)
# 3.886652

#Step 4: Look at the residuals
par(mfrow=c(2,2))
plot(lmodel)


#Step 5: Visualise the correlation betwee the oitcome medv and each predictor
library(corrplot)
corrplot(cor(train.data),type="upper",method="color",addCoef.col="black",number.cex=0.4)
#rm,lstat are hightly significant predictors
#Step 6: remove outliers
Boston1=Boston[-c(266,269,270),]
set.seed(100)
training.idx=sample(1:nrow(Boston1),size=nrow(Boston1)*0.8)
train.data=Boston1[training.idx,]
test.data=Boston1[-training.idx,]

#Step 7: choose predictors with high correlation (second order term)
p2model=lm(medv~crim+nox+rm+dis+rad+tax+ptratio+lstat+I(rm^2)+I(lstat^2)+I(rm*lstat),data=train.data)
summary(p2model)
predictions=predict(p2model,test.data)
RMSE(predictions,test.data$medv)
plot(p2model)                  

